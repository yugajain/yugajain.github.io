SECURE = (('s','$'), ('and','&'), ('a', '@'), ('o', '*'), ('i', '1'))

def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("Enter your secure password: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")


def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("your other password or if no you can close the termianal: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")

def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("your other password or if no you can close the termianal: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")
    

def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("your other password or if no you can close the termianal: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")

def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("your other password or if no you can close the termianal: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")

def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("your other password or if no you can close the termianal: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")

def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("your other password or if no you can close the termianal: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")

def SecurePassword(password):
    for a,b in SECURE:
        password = password.replace(a,b)
    return password


if __name__ == "__main__":
    password = input("your other password or if no you can close the termianal: ")
    password = SecurePassword(password)
    print(f"Your secure password is {password}")